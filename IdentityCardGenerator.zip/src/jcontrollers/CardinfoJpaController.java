/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package jcontrollers;

import entity.Cardinfo;
import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import jcontrollers.exceptions.NonexistentEntityException;

/**
 *
 * @author kingbarric
 */
public class CardinfoJpaController implements Serializable {

    public CardinfoJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Cardinfo cardinfo) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(cardinfo);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Cardinfo cardinfo) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            cardinfo = em.merge(cardinfo);
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                Integer id = cardinfo.getId();
                if (findCardinfo(id) == null) {
                    throw new NonexistentEntityException("The cardinfo with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(Integer id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Cardinfo cardinfo;
            try {
                cardinfo = em.getReference(Cardinfo.class, id);
                cardinfo.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The cardinfo with id " + id + " no longer exists.", enfe);
            }
            em.remove(cardinfo);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Cardinfo> findCardinfoEntities() {
        return findCardinfoEntities(true, -1, -1);
    }

    public List<Cardinfo> findCardinfoEntities(int maxResults, int firstResult) {
        return findCardinfoEntities(false, maxResults, firstResult);
    }

    private List<Cardinfo> findCardinfoEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Cardinfo.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Cardinfo findCardinfo(Integer id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Cardinfo.class, id);
        } finally {
            em.close();
        }
    }

    public int getCardinfoCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Cardinfo> rt = cq.from(Cardinfo.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
