/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package framegrabber;

/**
 *
 * @author kingbarric
 */
import static com.googlecode.javacv.cpp.opencv_core.cvFlip;
import com.googlecode.javacv.CanvasFrame;
import com.googlecode.javacv.FrameGrabber;
import com.googlecode.javacv.VideoInputFrameGrabber;
import com.googlecode.javacv.cpp.opencv_core.IplImage;
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.*;

public class GrabberShowTweak implements Runnable { //
IplImage img;
FrameGrabber grabber;
public JLabel imgDisplayLabel;
public boolean grabberMode = false;
    final int INTERVAL = 1000;///you may use interval IplImage image;
    CanvasFrame canvas = new CanvasFrame("barric3g Webcam ");
    

    public GrabberShowTweak(JLabel lbl) {
        this.imgDisplayLabel = lbl;
       
        //canvas.setDefaultCloseOperation(javax.swing.JFrame.HIDE_ON_CLOSE);
       canvas.addWindowListener(new WindowAdapter(){
       @Override
       public void windowClosing(WindowEvent e){
       
       canvas.dispose();
           try {
               if(grabberMode){
               grabber.release();
               grabber.stop();
               grabberMode = false;
               }
           } catch (FrameGrabber.Exception ex) {
               
           }
       }
       });
       
        canvas.add(new VideoCaptureBoard(this),BorderLayout.NORTH);
        canvas.setSize(600, 600);
        canvas.setResizable(false);
       
        JPanel jp = new JPanel();
        jp.setLayout(new FlowLayout());
        JButton jbn = new JButton("Start");
        jp.add(jbn);
       // canvas.add(jp);
       
        
    }

    @Override
    public void run() {
       grabber = new VideoInputFrameGrabber(0); // 1 for next camera 
     
        int i = 0;
        try {
          //  FrameRecorder  recorder = FFmpegFrameRecorder.createDefault("out.avi", 900, 400);
            grabber.start();
           //   recorder.start();
            grabberMode = true;
          
            while (true) {
                img = grabber.grab();
                
                if (img != null) {
                    cvFlip(img, img, 1);// l-r = 90_degrees_steps_anti_clockwise 
                  //  cvSaveImage((i++) + "-aa.jpg", img); // show image on window
                    canvas.showImage(img);
                //   recorder.record(img);
                } //Thread.sleep(INTERVAL); 
            }
        
         
   
  
    
      
        
        } catch (Exception e) { } }

    

    

  /*  public static void main(String[] args) {
        GrabberShowTweak gs = new GrabberShowTweak(new JLabel());
       Thread th = new Thread(gs);
        //th.start();
    }
    */
    
}
