/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package testpackage;

/**
 *
 * @author kingbarric
 */
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.sql.*;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;

public class StoreImage extends javax.swing.JFrame {

    Connection connection = null;
    PreparedStatement ps = null;
    ResultSet rs = null;
    String filePath = null;

    public StoreImage() {

        initComponents();
        initConnection();
        setSize(600, 500);
    }

    public void retriveImage() {
        try {
            String val = jTextField1.getText();
            if (val.length() > 0) {
                ps = connection.prepareStatement("select image from imagetest where id=?");
                ps.setObject(1, val);
                rs = ps.executeQuery();
                byte b[] = null;
                while (rs.next()) {
                    b = rs.getBytes(1);
                }
                ImageIcon image = new ImageIcon(Toolkit.getDefaultToolkit().createImage(b));
               final Image img = scaleImage(180, 150, image);
                ImageIcon im2 = new ImageIcon(img);
                jLabel6.setIcon(im2);


            } else {
                JOptionPane.showMessageDialog(this, "Please enter ID...");
            }


        } catch (Exception e) {
        }
    }

    public Image scaleImage(int WIDTH, int HEIGHT, ImageIcon ii) {
        BufferedImage bi = null;
        try {
            // ImageIcon ii = new ImageIcon(filename);//path to image
            bi = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
            Graphics2D g2d = (Graphics2D) bi.createGraphics();
            g2d.addRenderingHints(new RenderingHints(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY));
            g2d.drawImage(ii.getImage(), 0, 0, WIDTH, HEIGHT, null);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return (Image)bi;
    }

//1048576 Size limit allowed for Image storage in MySQL.
    public void storeImage() {
        try {

            JFileChooser chooser = new JFileChooser(new File("C:\\Users\\kingbarric\\Documents"));

            chooser.setMultiSelectionEnabled(false);
            chooser.setVisible(true);

            chooser.showOpenDialog(this);

            File file = chooser.getSelectedFile();
            if (file != null) {
                filePath = file.getPath();
            }
            if (filePath != null) {
                jLabel5.setText("File:" + " " + filePath);
                jLabel6.setIcon(new ImageIcon(filePath));
            }


            if (filePath != null && check()) {
                ps = connection.prepareStatement("insert  into imagetest (id,image) values(?,?)");
                FileInputStream fileInputStream = new FileInputStream(filePath);
                byte b[] = new byte[fileInputStream.available()];
                fileInputStream.read(b);
                fileInputStream.close();
                ps.setObject(1, jTextField1.getText());
                ps.setBytes(2, b);
                int val = ps.executeUpdate();
                if (val >= 1) {
                    JOptionPane.showMessageDialog(this, "Succesfully Stored...");
                } else {
                    JOptionPane.showMessageDialog(this, "Error in storage...");
                }

            } else {
                JOptionPane.showMessageDialog(this, "Please select an Image of type .jpeg/gif/jpg...");
            }

        } catch (Exception e) {

            JOptionPane.showMessageDialog(this, e.getMessage());
            e.printStackTrace();
        }
    }

    public void initConnection() {
        try {

            Class.forName("com.mysql.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/identitycardgenerator", "root", "");
            System.out.println("Connection Established Succcesfully...");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        }
    }

    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jTextField1 = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jLabel6 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel1.setText("Store/Retive Image From MySQL");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(90, 30, 220, 14);

        jLabel2.setText("ID :");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(60, 90, 18, 14);

        jLabel3.setText("Select an Image :");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(40, 130, 100, 14);

        jButton1.setText("Browse");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1);
        jButton1.setBounds(150, 123, 100, 30);

        jButton3.setText("Show");
        jButton4.setText("Print..");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

//printing button action
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                printer();
            }
        });

        getContentPane().add(jButton3);
        getContentPane().add(jButton4);
        jButton3.setBounds(130, 213, 80, 30);
        jButton4.setBounds(120, 300, 50, 10);
        getContentPane().add(jTextField1);
        jTextField1.setBounds(150, 80, 90, 20);

        jLabel5.setForeground(new java.awt.Color(255, 0, 0));
        getContentPane().add(jLabel5);
        jLabel5.setBounds(40, 170, 240, 30);

        jScrollPane1.setViewportView(jLabel6);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(330, 70, 210, 160);

        pack();
    }

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {
        storeImage();
    }

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {
        retriveImage();
    }

    public static void main(String args[]) {
        new StoreImage().setVisible(true);
    }
// Variables declaration - do not modify
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextField jTextField1;
// End of variables declaration

    private void printer() {
        PrintUtilities.printComponent(jLabel6);
    }

    private boolean check() {
        if (filePath != null) {
            if (filePath.endsWith(".jpeg") || filePath.endsWith(".gif") || filePath.endsWith(".jpg") || filePath.endsWith(".JPEG") || filePath.endsWith(".GIF") || filePath.endsWith(".JPG")) {
                return true;
            }
            return false;
        }
        return false;
    }
}
