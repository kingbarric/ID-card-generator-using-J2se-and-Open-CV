/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package testpackage;

import com.identitygenerator.forms.*;
import java.text.DateFormat;
import java.text.FieldPosition;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.StringTokenizer;

/**
 *
 * @author kingbarric
 */
public class DateTest {
 public DateTest(){
 Date dt = new Date();
    DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT);
    DateFormat df2 = DateFormat.getTimeInstance(DateFormat.MEDIUM,Locale.FRENCH);
    String date = df.format(dt);
    String time = df2.format(dt);
    Long now = System.currentTimeMillis();
    String tes = now.toString();
    
    String state ="abia";
     StringTokenizer tok = new StringTokenizer(date,"/");
        String plainDate = "";
        while(tok.hasMoreTokens()){
        plainDate +=tok.nextElement().toString();
        }
        String strSub = tes.substring(9);
        String fin = strSub+"-"+plainDate;
        for(int i = 0; i<=50; i++)
    System.out.println(strSub);
    
     StringBuffer buffer = new StringBuffer();

    Calendar date2 = Calendar.getInstance();
    DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.SHORT, Locale.US);
    FieldPosition yearPosition = new FieldPosition(DateFormat.YEAR_FIELD);

    StringBuffer format = dateFormat.format(date2.getTime(), buffer, yearPosition);
    format.replace(yearPosition.getBeginIndex(), yearPosition.getEndIndex(), String.valueOf(date2.get(Calendar.YEAR)));

    System.out.println(format);
   
    
 }   
 
 public static void main(String args[]){
 new DateTest();
 }
}
