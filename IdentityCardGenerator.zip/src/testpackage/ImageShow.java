/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package testpackage;

import com.identitygenerator.forms.*;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Toolkit;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

/**
 *
 * @author kingbarric
 */
    public class ImageShow extends JFrame{
    ResultSet r;
    Image img;
    public ImageShow() throws SQLException
    {
    setTitle("Image retrieved");
    setSize(500, 500);
    setDefaultCloseOperation(HIDE_ON_CLOSE);
    Container pane = getContentPane();
    pane.setLayout(new GridLayout(3,3));
    String query = "select image from cardinfo where id = ?";
       dbcon con  = new dbcon();
            con.callableStatement(query);
            con.callState.setInt(1, 2);
            r = con.callState.executeQuery();
    while (r.next())
    {
    byte[] imagedata = r.getBytes(1) ;
    img = Toolkit.getDefaultToolkit().createImage(imagedata);
    img = img.getScaledInstance(200,200,Image.SCALE_SMOOTH);
    ImageIcon icon =new ImageIcon(img);
    JLabel Photo = new JLabel(icon) ;
    pane.add(Photo) ;
    
    }
    this.pack();
    this.setVisible(true);
    }
    
    
    public static void main(String args[]){
        try{
    new ImageShow();
        }catch(Exception ex){}
    }
    }
