/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package testpackage;

/**
 *
 * @author kingbarric
 */
import datepickerapplication.Main;
import java.awt.event.KeyListener;
///import  sun.audio.*;    //import the sun.audio package
import  java.io.*;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.JFrame;
public class SoundPlayer {
    public SoundPlayer(){
       
    }
    
    void playS(){
     try{
        File Filename  = new File("sounds/camera-shutter.wav");
    InputStream in = new FileInputStream(Filename);
// Create an AudioStream object from the input stream.
//AudioStream as = new AudioStream(in);         
// Use the static class member "player" from class AudioPlayer to play
// clip.
//AudioPlayer.player.start(as); 
//AudioPlayer.player.stop(as);  
// Similarly, to stop the audio.
//AudioPlayer.player.stop(as);
        }catch(Exception e){
        e.printStackTrace();
        }
    }
    
    public static  void playSound(final String url) {
  new Thread(new Runnable() {
  // The wrapper thread is unnecessary, unless it blocks on the
  // Clip finishing; see comments.
    public void run() {
      try {
        Clip clip = AudioSystem.getClip();
        AudioInputStream inputStream = AudioSystem.getAudioInputStream(
          Main.class.getResourceAsStream(url));
        clip.open(inputStream);
        clip.start(); 
      } catch (Exception e) {
        System.err.println(e.getMessage());
        e.printStackTrace();
      }
    }
  }).start();
}
    
    public static void main(String args[]){
 //   new SoundPlayer().playS();
      //  playSound("sounds/camera-shutter.wav");
                JFrame frame = new JFrame();
        frame.setSize(300,300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

        KeyListener s;

        try {
            AudioInputStream audio = AudioSystem.getAudioInputStream(new File("sounds/camera-shutter.wav"));
            Clip clip = AudioSystem.getClip();
            clip.open(audio);
            clip.start();
        }
        
        catch(UnsupportedAudioFileException uae) {
            System.out.println(uae);
        }
        catch(IOException ioe) {
            System.out.println(ioe);
        }
        catch(LineUnavailableException lua) {
            System.out.println(lua);
        }
    }
}
