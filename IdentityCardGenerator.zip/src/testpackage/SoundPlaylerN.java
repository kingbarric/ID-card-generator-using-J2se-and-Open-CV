/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package testpackage;

/**
 *
 * @author barric3g
 */
import java.io.*;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import sun.audio.*;
public class SoundPlaylerN {
 
    public  SoundPlaylerN(){
       InputStream in = null;
        try {
            in = new FileInputStream(new java.io.File("sounds/camera-shutter.wav"));
            AudioStream as = new AudioStream(in);
            AudioPlayer.player.start();
            System.out.println("Playing sound....");
        } catch (Exception ex) {
            Logger.getLogger(SoundPlaylerN.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    
    }
    public static void main(String[] args) {
        new SoundPlaylerN();
    }
}
