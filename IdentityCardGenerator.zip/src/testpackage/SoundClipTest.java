/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package testpackage;

/**
 *
 * @author kingbarric
 */
import java.awt.Desktop;
import java.io.*;
import java.net.URL;
import javax.sound.sampled.*;
import javax.swing.*;

// To play sound using Clip, the process need to be alive.
// Hence, we use a Swing application.
public class SoundClipTest extends JFrame {

   // Constructor
   public SoundClipTest() {
      this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      this.setTitle("Test Sound Clip");
      this.setSize(300, 200);
      this.setVisible(true);

      try {
         // Open an audio input stream.
         URL url = this.getClass().getClassLoader().getResource("sounds/camera-shutter-click-01.wav");
          //getClass().getClassLoader().getResource(null)
       //  URL url1 = new URL(null,"sounds/camera-shutter.wav");
         Desktop d = Desktop.getDesktop();
         d.open(new File("sounds/camera-shutter.mp3"));
         AudioInputStream audioIn = AudioSystem.getAudioInputStream(url);
         // Get a sound clip resource.
         Clip clip = AudioSystem.getClip();
        
         // Open audio clip and load samples from the audio input stream.
         clip.open(audioIn);
         clip.start();
      } catch (UnsupportedAudioFileException | IOException | LineUnavailableException e) {
          System.out.println("Error: "+e.getMessage());
      }
   }

   public static void main(String[] args) {
      new SoundClipTest();
   }
}
