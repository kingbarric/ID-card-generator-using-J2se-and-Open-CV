/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package testpackage;

import com.identitygenerator.forms.*;
import java.awt.*;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.ResultSet;

import javax.swing.*;



/**
 *
 * @author kingbarric
 */
public class PanelTest extends JDialog {
    public JLabel label = new JLabel("Hello world");
    public JLabel labelpan1 = new JLabel("pan 1 label");
    public JLabel labelpan2 = new JLabel("pan 2 label");
    private JPanel pan1,pan2;
    
    TryPanel pa = new TryPanel();
    public PanelTest(JFrame frame,boolean modal){
    setSize(300, 400);
    Container cn = getContentPane();
   // cn.setLayout(new FlowLayout());
    pan2 = new JPanel();
    pan2.setBackground(Color.red);
    pan2.setPreferredSize(new Dimension(150, 200));
    pan1 = new JPanel();
  //  pan1.add(labelpan1);
    
    
    pan2.add(pan1);
    pan2.add(pa,BorderLayout.CENTER);
    cn.add(label,BorderLayout.NORTH);
    cn.add(pan2,BorderLayout.CENTER);
    
    }
    
   
    
    public static void main(String args[]){
    
    PanelTest tester = new PanelTest(new JFrame(),true);
    tester.setVisible(true);
    }
}
class TryPanel extends JPanel{
ImageIcon icon;// = new ImageIcon(this.getClass().getResource("/images/background.png"));
ImageIcon icon2 = new ImageIcon(this.getClass().getResource("/images/placeholder.jpg"));
Image image,image2;
Image frmDb;
public TryPanel(){
   setPreferredSize(new Dimension(200, 220));
  // getImageById(6);
   // this.setBackground(Color.red);
   String query = "select image from imagetest where id = ?";
        try {
            con.callableStatement(query);
            con.callState.setInt(1, 2);
            ResultSet rs = con.callState.executeQuery();
           
            if (rs.next()) {
                byte[] bytes = null;
            if (rs.next()) {
                bytes = rs.getBytes(1);
            }
            if (bytes != null) {
                image = toImage(bytes);
            }
                   frmDb = image;
                 //  icon = new ImageIcon(imag);
  
            }
           

        } catch (Exception ex) {
            System.out.println("error "+ex.getMessage());
            ex.printStackTrace();
        }
 //image = icon.getImage();
 image2 = icon2.getImage();
 
//JLabel lbl = new JLabel(icon);
//this.add(lbl);

}



  @Override
      /*  public void paintComponent(Graphics g) {
            super.paintComponent(g);
            g.drawImage(frmDb, 0, 0, null);
            this.revalidate();
            this.repaint();
        }*/
  
   public void paint(Graphics g) {
        super.paint(g);
        Graphics2D g2d = (Graphics2D) g;
        g2d.drawImage(image, 10, 10, null); 
    }
   dbcon con = new dbcon();
   public void getImageById(int id) {
        String query = "select image from imagetest where id = ?";
        try {
            con.callableStatement(query);
            con.callState.setInt(1, id);
            ResultSet rs = con.callState.executeQuery();
           
            if (rs.next()) {
           Blob test=rs.getBlob(1);
InputStream x=test.getBinaryStream();
int size=x.available();
OutputStream out=new FileOutputStream("50cent.jpg");
byte b[]= new byte[size];
System.out.println("name as ...."+rs.getString(1));
x.read(b);
out.write(b);
System.out.println("Savd....");
                   
            }
           

        } catch (Exception ex) {
            System.out.println("error "+ex.getMessage());
            ex.printStackTrace();
        }
    }

    public Image toImage(byte[] bytes) {
        return Toolkit.getDefaultToolkit().createImage(bytes);
    }
}
