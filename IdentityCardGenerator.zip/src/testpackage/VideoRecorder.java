/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package testpackage;
import static com.googlecode.javacv.cpp.opencv_core.cvFlip;
import com.googlecode.javacv.CanvasFrame;
import com.googlecode.javacv.FFmpegFrameRecorder;
import com.googlecode.javacv.FrameGrabber;
import com.googlecode.javacv.FrameRecorder;
import com.googlecode.javacv.OpenCVFrameGrabber;
import com.googlecode.javacv.cpp.avcodec;
import com.googlecode.javacv.cpp.avutil;
import com.googlecode.javacv.cpp.opencv_core.IplImage;

/**
 *
 * @author kingbarric
 */
public class VideoRecorder {
    public static void main(String[] args) {
        CanvasFrame canvas = new CanvasFrame("Web Cam");
        FFmpegFrameRecorder recorder=null;
        OpenCVFrameGrabber grabber=null;
        try {                  
            grabber = new OpenCVFrameGrabber(0);
            grabber.setAudioChannels(1);           
            grabber.start();
            IplImage grabbedImage = grabber.grab();    
            canvas.setCanvasSize(grabbedImage.width(), grabbedImage.height());
            recorder = new FFmpegFrameRecorder("demo.mp4", 1900, 1400,grabber.getAudioChannels());
            recorder.setVideoCodec(avcodec.AV_CODEC_ID_MPEG4);
            recorder.setFormat("mp4");           
            recorder.setPixelFormat(avutil.AV_PIX_FMT_YUV420P);
            recorder.setFrameRate(15);
            recorder.setVideoBitrate(5*1024);

            recorder.setAudioBitrate(16*1024);
            recorder.setAudioCodec(avcodec.AV_CODEC_ID_MP3);
            recorder.setAudioChannels(1);           

            recorder.start();
            System.out.println("framerate = " + grabber.getFrameRate());
            while (canvas.isVisible() && (grabbedImage = grabber.grab()) != null) {
                cvFlip(grabbedImage, grabbedImage, 1);
                canvas.showImage(grabbedImage);
                recorder.record(grabbedImage);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        finally{
            try {
                if(recorder!=null)
                    recorder.stop();

                if(grabber!=null)
                    grabber.stop();
                canvas.dispose();
            } catch (FrameRecorder.Exception ex) {
             
            } catch (FrameGrabber.Exception ex) {
               
            } 
        }
    }
}
