/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package testpackage;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.awt.print.PageFormat;
import java.awt.print.Paper;
import java.awt.print.Printable;
import java.awt.print.PrinterJob;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JTable;
import javax.swing.table.AbstractTableModel;
import javax.swing.table.JTableHeader;

/**
 *
 * @author kingbarric
 */
public class PrintTableTest {

    public static void main(String[] args) {

        final JTable table1 = new JTable(new AbstractTableModel() {
            @Override
            public int getRowCount() {
                return 3;
            }

            @Override
            public int getColumnCount() {
                return 3;
            }

            @Override
            public String getColumnName(int column) {
                String name = null;
                switch (column) {
                    case 0:
                        name = "Day";
                        break;
                    case 1:
                        name = "FirstName";
                        break;
                    case 2:
                        name = "LastName";
                        break;
                }
                return name;
            }

            @Override
            public Object getValueAt(int rowIndex, int columnIndex) {
                Object value = null;
                switch (columnIndex) {
                    case 0:
                        switch (rowIndex) {
                            case 0:
                                value = "First";
                                break;
                            case 1:
                                value = "Second";
                                break;
                            case 2:
                                value = "Final";
                                break;
                        }
                        break;
                }
                return value;
            }
        });
        int rowHeight = (int) Math.floor(((700f / 2f) - table1.getTableHeader().getPreferredSize().height) / 3f);
        table1.setRowHeight(rowHeight);

        PrinterJob printjob = PrinterJob.getPrinterJob();
        printjob.setJobName(" TESSCO CUSTOMER CARD ");

        Printable printable;
        printable = new Printable() {
            public int print(Graphics pg, PageFormat pf, int pageNum) {

                if (pageNum > 0) {
                    return NO_SUCH_PAGE;
                }

                Graphics2D g2d = (Graphics2D) pg;

                double pageWidth = pf.getImageableWidth();
                double pageHeight = pf.getImageableHeight();

                double pageX = pf.getImageableX();
                double pageY = pf.getImageableY();

                g2d.translate(pageX, pageY);

                // Each table will take half the page...
                double tableHeight = pageHeight / 2d;

                // We need to print the header as well...
                JTableHeader header = table1.getTableHeader();
                int headerHeight = header.getPreferredSize().height;

                int yOffset = 0;

                for (int index = 0; index < 2; index++) {
                    // Set the bounds of the components
                    // The yOffset is actuall irrelevent to us, but for consitency sake
                    // we'll keep it.
                    header.setBounds(0, yOffset, (int) Math.floor(pageWidth), headerHeight);
                    table1.setBounds(0, yOffset + headerHeight, (int) Math.floor(pageWidth), (int) Math.floor(tableHeight));
                    // Force the components to update there internal layouts to match
                    // the new size. We need to do this because, technically, we're not
                    // attached to any peer, nor do we want them to be taking into account
                    // the dimensions of any parent any way :P
                    table1.doLayout();
                    header.doLayout();

                    // Translate the graphics.  Components asume a position of 0x0 when
                    // painting.  This is a side effect of the AWT/Swing painting engine
                    // (for which we are greatful), but we need to simulate the change
                    g2d.translate(0, yOffset);
                    header.printAll(g2d);
                    // Translations are relative to the last translation...
                    g2d.translate(0, headerHeight);
                    table1.printAll(g2d);
                    // Reset the last translation
                    g2d.translate(0, -(headerHeight + yOffset));

                    // Next table...
                    yOffset += table1.getHeight();
                }
                return Printable.PAGE_EXISTS;
            }
        };

        Paper paper = new Paper();
        paper.setImageableArea(0, 0, 700, 890);
        paper.setSize(700, 890);

        PageFormat format = new PageFormat();
        format.setPaper(paper);
        format.setOrientation(PageFormat.LANDSCAPE);

//        printjob.setPrintable(printable, format);
        BufferedImage img = new BufferedImage(890, 700, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = img.createGraphics();
        g2d.setColor(Color.WHITE);
        g2d.fill(new Rectangle(0, 0, 890, 700));
        try {
            printable.print(g2d, format, 0);
        } catch (Exception exp) {
            exp.printStackTrace();
        }
        g2d.dispose();

        try {
            ImageIO.write(img, "png", new File("Print.png"));
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}
