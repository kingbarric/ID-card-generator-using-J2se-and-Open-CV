/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package entity;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author kingbarric
 */
@Entity
@Table(name = "cardinfo")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Cardinfo.findAll", query = "SELECT c FROM Cardinfo c"),
    @NamedQuery(name = "Cardinfo.findById", query = "SELECT c FROM Cardinfo c WHERE c.id = :id"),
    @NamedQuery(name = "Cardinfo.findBySurname", query = "SELECT c FROM Cardinfo c WHERE c.surname = :surname"),
    @NamedQuery(name = "Cardinfo.findByOtherNames", query = "SELECT c FROM Cardinfo c WHERE c.otherNames = :otherNames"),
    @NamedQuery(name = "Cardinfo.findByIdNo", query = "SELECT c FROM Cardinfo c WHERE c.idNo = :idNo"),
    @NamedQuery(name = "Cardinfo.findByLocation", query = "SELECT c FROM Cardinfo c WHERE c.location = :location"),
    @NamedQuery(name = "Cardinfo.findByExpiryDate", query = "SELECT c FROM Cardinfo c WHERE c.expiryDate = :expiryDate"),
    @NamedQuery(name = "Cardinfo.findByBloodGroup", query = "SELECT c FROM Cardinfo c WHERE c.bloodGroup = :bloodGroup"),
    @NamedQuery(name = "Cardinfo.findByHeight", query = "SELECT c FROM Cardinfo c WHERE c.height = :height"),
    @NamedQuery(name = "Cardinfo.findByDateAdded", query = "SELECT c FROM Cardinfo c WHERE c.dateAdded = :dateAdded")})
public class Cardinfo implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "id")
    private Integer id;
    @Basic(optional = false)
    @Column(name = "surname")
    private String surname;
    @Basic(optional = false)
    @Column(name = "other_names")
    private String otherNames;
    @Basic(optional = false)
    @Column(name = "id_no")
    private String idNo;
    @Basic(optional = false)
    @Column(name = "location")
    private String location;
    @Basic(optional = false)
    @Column(name = "expiry_date")
    private String expiryDate;
    @Basic(optional = false)
    @Column(name = "blood_group")
    private String bloodGroup;
    @Basic(optional = false)
    @Column(name = "height")
    private String height;
    @Basic(optional = false)
    @Lob
    @Column(name = "image")
    private byte[] image;
    @Basic(optional = false)
    @Column(name = "date_added")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateAdded;

    public Cardinfo() {
    }

    public Cardinfo(Integer id) {
        this.id = id;
    }

    public Cardinfo(Integer id, String surname, String otherNames, String idNo, String location, String expiryDate, String bloodGroup, String height, byte[] image, Date dateAdded) {
        this.id = id;
        this.surname = surname;
        this.otherNames = otherNames;
        this.idNo = idNo;
        this.location = location;
        this.expiryDate = expiryDate;
        this.bloodGroup = bloodGroup;
        this.height = height;
        this.image = image;
        this.dateAdded = dateAdded;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getOtherNames() {
        return otherNames;
    }

    public void setOtherNames(String otherNames) {
        this.otherNames = otherNames;
    }

    public String getIdNo() {
        return idNo;
    }

    public void setIdNo(String idNo) {
        this.idNo = idNo;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public String getBloodGroup() {
        return bloodGroup;
    }

    public void setBloodGroup(String bloodGroup) {
        this.bloodGroup = bloodGroup;
    }

    public String getHeight() {
        return height;
    }

    public void setHeight(String height) {
        this.height = height;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }

    public Date getDateAdded() {
        return dateAdded;
    }

    public void setDateAdded(Date dateAdded) {
        this.dateAdded = dateAdded;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Cardinfo)) {
            return false;
        }
        Cardinfo other = (Cardinfo) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entity.Cardinfo[ id=" + id + " ]";
    }
    
}
