/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package sounds;

/**
 *
 * @author barric3g
 */
import java.awt.FlowLayout;
import javax.media.*;
import java.io.*;
import java.net.MalformedURLException;
import javax.swing.*;
public class MediaPlayer extends Object
	implements ControllerListener {

	File soundFile;
	JDialog playingDialog;

	public static void main (String[] args) {
		
		File f = new File("sounds/camera-shutter-click-01.wav");
		try {
			MediaPlayer s = new MediaPlayer (f);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public MediaPlayer (File f)
		throws NoPlayerException, CannotRealizeException,
				MalformedURLException, IOException {
		soundFile = f;
		// prepare a dialog to display while playing
		JOptionPane pane = new JOptionPane ("Playing " + f.getName(),
								JOptionPane.PLAIN_MESSAGE);
		 JPanel pn = new JPanel(new FlowLayout());
                pn.add(new JTextArea("Am in text"));
                 pn.add(new JButton("Am i"));
                pane.add(pn);
                playingDialog = pane.createDialog (null, "JMF Sound");
               
        playingDialog.pack();

		// get a player
		MediaLocator mediaLocator =
			new MediaLocator(soundFile.toURL());
		Player player =
			Manager.createRealizedPlayer (mediaLocator);
player.addControllerListener (this);
	      player.prefetch();
		  player.start();
		  playingDialog.setVisible(true);
	}
	// ControllerListener implementation
	public void controllerUpdate (ControllerEvent e) {
       System.out.println (e.getClass().getName());
	   if (e instanceof EndOfMediaEvent) {
			playingDialog.setVisible(false);
			System.exit (0);
		}
	}
}
