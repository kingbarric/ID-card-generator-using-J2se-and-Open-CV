/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package datepickerapplication;

import javax.swing.JOptionPane;

/**
 *
 * @author Damith
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        try {


    javax.swing.UIManager.setLookAndFeel("com.birosoft.liquid.LiquidLookAndFeel");


        }

    catch (Exception e)

    {

    JOptionPane.showMessageDialog(null, e.getMessage());

    }


        new myMian().setVisible(true);
        // TODO code application logic here
    }

}
