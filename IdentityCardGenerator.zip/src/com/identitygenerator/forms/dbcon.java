/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.identitygenerator.forms;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.ImageIcon;
import javax.swing.JFrame;

/**
 *
 * @author kingbarric
 */
public class dbcon {
    
    private  String USERNAME ;//= "kingbarric";
    private  String PASSWORD ;//= "baridule2";
    private  String URL ;//= "jdbc:mysql://127.0.0.1:3306/identitycardgenerator";
    private final String DRIVER = "com.mysql.jdbc.Driver";
    public Connection con;
    public ResultSet resultSet;
    public PreparedStatement prepSt;
    public CallableStatement callState;
    private Statement statement;
    public int numRows;
    XMLConfiguration xmlConfig;
    public dbcon() {
         ImageIcon icon = new ImageIcon(this.getClass().getResource("/icons/Error.gif"));
        try {
            xmlConfig= new XMLConfiguration();
            xmlConfig.read();
            USERNAME = xmlConfig.getUserName();
            PASSWORD = xmlConfig.getPassword();
            String dbname = xmlConfig.getDatabaseName();
            String server = xmlConfig.getServerName();
            URL = "jdbc:mysql://"+server+":3306/"+dbname+"";
            Class.forName(DRIVER);
            con = DriverManager.getConnection(URL, USERNAME, PASSWORD);
            System.out.println("Successful connection");
        } catch (ClassNotFoundException | SQLException cl) {
        ServerConfig ser=   new ServerConfig(new JFrame(),true);
        ser.jLabelError.setText("PROBLEM WITH CONNECTION PLEASE ENTER CORRECT PARAMETERS");
        ser.setIconImage(icon.getImage());
        ser.jLabelError.setIcon(icon);
        ser.setVisible(true);
        } 
    }

    public void prepState(String statement) {
        try {
            prepSt = con.prepareStatement(statement,
                    ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            resultSet = prepSt.executeQuery();

        } catch (SQLException ex) {
            ex.printStackTrace();
        }
    }

    public void callableStatement(String s) {
        try {
            callState = con.prepareCall(s, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);

        } catch (Exception e) {
        }
    }

}
