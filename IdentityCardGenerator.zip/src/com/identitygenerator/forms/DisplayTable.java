package com.identitygenerator.forms;


import java.sql.Connection;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;



/**
 *
 * @author Barric3Gsystems
 */
public class DisplayTable {
  dbcon dbc;
    Connection connect;
    Statement statement;
    JTable tableq;
    StringBuilder strCol = new StringBuilder();
     StringBuilder strRow  = new StringBuilder();
    String query;
    ResultSetMetaData meta;
    public DisplayTable(JTable table,String q){
      
        tableq = table;
        
        query = q;
    }
    //to execute table query
    public void executeTable(){
      dbc = new  dbcon();
    DefaultTableModel tm2 = new DefaultTableModel();
    
    tableq.setModel(tm2);
    
    try{
        dbc.prepState(query);
if(dbc.resultSet !=null){
  
    meta = dbc.resultSet.getMetaData();
  
  int numCol = meta.getColumnCount();

   String[] roll  ;
  for(int i = 1; i<=numCol; i++){
      tm2.addColumn(meta.getColumnName(i));
      
  }
  
  int key = 0;
       while(dbc.resultSet.next()){
        Vector vc = new Vector();    
     for(int b = 1; b<=numCol; b++){
         key = b-1;
       vc.add(key,dbc.resultSet.getString(b));
       
     }
     tm2.addRow(vc);
       
      } 
  
} else{}

    }catch(SQLException e){
 
    }
    
}
     
    
}
