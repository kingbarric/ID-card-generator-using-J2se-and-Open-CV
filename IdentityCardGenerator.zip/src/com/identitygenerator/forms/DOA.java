/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.identitygenerator.forms;

import java.awt.Image;
import java.awt.Toolkit;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;

/**
 *
 * @author kingbarric
 */
public  class DOA {
   static dbcon  dbc = new dbcon();
    
    public static void getContries(JComboBox jcb){
    try{
    dbc = new dbcon();
dbc.callableStatement("SELECT * FROM nigerian_states");
            //dbc.callState.setInt(1, id);
            ResultSet rs = dbc.callState.executeQuery();
         jcb.removeAll();
         jcb.addItem("choose Location");
         
            while(rs.next()){
               
                jcb.addItem(rs.getString(2));
            }
        
    }catch(Exception ex){
    }
    }
    
    public static String  insertUpdateValues(int id,String fn,String ln,String loc,String expd,String blgrp,String hgt,byte[] img){
    try{
      dbc = new dbcon();
      String sql;
      if(id== 0){
      sql = "INSERT INTO cardinfo (surname,other_names,id_no,location,expiry_date,blood_group, "
                    + " height, image ) VALUES  (?,?,?,?,?,?,?,?) ";
       dbc.callableStatement(sql);
            dbc.callState.setString(1,fn);
            dbc.callState.setString(2,ln);
            dbc.callState.setString(3,getIDSerial(loc));
            dbc.callState.setString(4,loc);
            dbc.callState.setString(5,expd);
            dbc.callState.setString(6,blgrp);
            dbc.callState.setString(7,hgt);
            dbc.callState.setBytes(8,img);
            dbc.callState.executeUpdate();
      
      }else{
      sql = "UPDATE cardinfo SET surname = ?,other_names = ?,location = ? , expiry_date = ? ,blood_group = ?, "
                    + " height = ? , image = ?  WHERE id = ? ";
       dbc.callableStatement(sql);
            dbc.callState.setString(1,fn);
            dbc.callState.setString(2,ln);
            dbc.callState.setString(3,loc);
            dbc.callState.setString(4,expd);
            dbc.callState.setString(5,blgrp);
            dbc.callState.setString(6,hgt);
            dbc.callState.setBytes(7,img);
            dbc.callState.setInt(8, id);
            dbc.callState.executeUpdate();
      }
             
            
           
            ImageLib.by = null;
            return "Successful operation";
            
    }catch(Exception ex){
        System.out.println("error "+ex.getMessage());
    return "Error "+ex.getMessage();
    }
    
    }
    
    private static String getIDSerial(String state){
    Long now = System.currentTimeMillis();
    String tes = now.toString();
     String strSub1 = tes.substring(8);
        String strSub = state.substring(0, 2);
        
    return strSub+"-"+strSub1;
    }
    
    private static  HashMap map;
    
    public static HashMap getDetailsByID(int id){
    
    try{
    String sql = "SELECT * FROM cardinfo WHERE id = ?";
    dbc.callableStatement(sql);
    
    map = new HashMap();
            dbc.callState.setInt(1,id);
   ResultSet rs=          dbc.callState.executeQuery();
            while(rs.next()){
            map.put(1, rs.getString(2));
            map.put(2, rs.getString(3));
            map.put(3, rs.getString(4));
            map.put(4, rs.getString(5));
            map.put(5, rs.getString(6));
             map.put(6, rs.getString(7));
            map.put(7, rs.getString(8));
            map.put(8, rs.getBytes(9));
            }
            return map;
    }catch(Exception ex){
    
    return null;}
    }
    
    public  boolean delete(int id){
        ImageIcon icon = new javax.swing.ImageIcon(getClass().getResource("/com/record/frames/mono-icons/warning32.png"));
       try {
           String sql = "DELETE FROM cardinfo WHERE id = ?";
           dbc.callableStatement(sql);
            dbc.callState.setInt(1,id);
            int q = JOptionPane.showConfirmDialog(null,"Are you sure ", "Confirm delete",JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, icon);
            if(q==JOptionPane.YES_OPTION){
              int i =  dbc.callState.executeUpdate(); 
              System.out.println("Ok deleted");
                if(i==1){
                return true;
                }
           
            }
       } catch (SQLException ex) {
           return false;
          
       }
       return false;
    }
    
    public static Image getImageById(int id){
        Image image = null;
       
        
     try{
    String sql = "SELECT image FROM cardinfo WHERE id = ? ";
    dbc.callableStatement(sql);
   
            dbc.callState.setInt(1,id);
   ResultSet result=          dbc.callState.executeQuery();
           byte[] bytes = null;
            if (result.next()) {
                bytes = result.getBytes(1);
            }
            if (bytes != null) {
                 System.out.println("not null");
                image = toImage(bytes);
            }else{
            System.out.println("is null");
            }
          return image;
           
    }catch(SQLException ex){
        System.out.println("Error : "+ex.getMessage());
        return null;
   }
    }
    
     public static Image toImage(byte[] bytes) {
        return Toolkit.getDefaultToolkit().createImage(bytes);
    }
}
