/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.identitygenerator.forms;
import java.io.File;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import java.awt.Graphics2D;
import java.awt.HeadlessException;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte;
import java.awt.image.WritableRaster;
import java.io.FileInputStream;
import java.io.IOException;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
/**
 *
 * @author kingbarric
 */
public class ImageLib {
      private static final int IMG_WIDTH = 120;
    private static final int IMG_HEIGHT = 120;
    public JLabel label;
    public ImageIcon photo;
    public WritableRaster raster;
    public DataBufferByte data;
    public File image;
     String filePath = null;
    public static  byte by[]=null;
    
    public boolean browseImage(JLabel labelImg,JLabel labelName,JInternalFrame frame){
      try {

            JFileChooser chooser = new JFileChooser();

            chooser.setMultiSelectionEnabled(false);
            chooser.setVisible(true);

            chooser.showOpenDialog(frame);

            File file = chooser.getSelectedFile();
            if (file != null) {
                filePath = file.getPath();
            }
            if (filePath != null) {
                labelName.setText("File:" + " " + filePath);
                ImageIcon ic = new ImageIcon(filePath);
                Image img = scaleImage(labelImg.getBounds().width, labelImg.getBounds().height, ic);
                labelImg.setIcon(new ImageIcon(img));
            }


            if (filePath != null && check()) {
                try (FileInputStream fileInputStream = new FileInputStream(filePath)) {
                    by = new byte[fileInputStream.available()];
                   fileInputStream.read(by);
                   
                }
            } else {
                JOptionPane.showMessageDialog(null, "Please select an Image of type .jpeg/gif/jpg...");
            }

        } catch (HeadlessException | IOException e) {

            JOptionPane.showMessageDialog(null, e.getMessage());
        }
        return true;
    }
    
    
     public Image toImage(BufferedImage bufferedImage) {
        return Toolkit.getDefaultToolkit().createImage(bufferedImage.getSource());
    }
     
     public Image scaleImage(int WIDTH, int HEIGHT, ImageIcon ii) {
        BufferedImage bi = null;
        try {
            // ImageIcon ii = new ImageIcon(filename);//path to image
            bi = new BufferedImage(WIDTH, HEIGHT, BufferedImage.TYPE_INT_RGB);
            Graphics2D g2d = (Graphics2D) bi.createGraphics();
            g2d.addRenderingHints(new RenderingHints(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY));
            g2d.drawImage(ii.getImage(), 0, 0, WIDTH, HEIGHT, null);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return (Image)bi;
    }
      
       private boolean check() {
        if (filePath != null) {
            if (filePath.endsWith(".jpeg") || filePath.endsWith(".gif") || filePath.endsWith(".jpg") || filePath.endsWith(".JPEG") || filePath.endsWith(".GIF") || filePath.endsWith(".JPG")) {
                return true;
            }
            return false;
        }
        return false;
    }
       
       
   public Image retrieveImage(byte[] byt){
   ImageIcon image = new ImageIcon(Toolkit.getDefaultToolkit().createImage(byt));
               final Image img = scaleImage(180, 150, image);
               return img;
   }    
}
