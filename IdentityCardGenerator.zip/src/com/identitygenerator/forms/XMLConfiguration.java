/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.identitygenerator.forms;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JOptionPane;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

/**
 *
 * @author kingbarric
 */
public class XMLConfiguration {
    private String serverName;
    private String port;
    private String databaseName;
    private String userName;
    private String password;
    private File file;
    private Document doc;//
    private String rememberMe;
    private String reUsername;
    private String rePassword;
    public XMLConfiguration(){
    
    try{
      
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            // Obtain builder instance
            DocumentBuilder db = dbf.newDocumentBuilder();
           try {
            file = new File("config/serverconfig.xml");
             doc = db.parse(file);
        } catch (IOException e) {
            createTheFile();
            file = new File("config/serverconfig.xml");
             doc = db.parse(file);
          //  e.printStackTrace();
        }
        
         //  createTheFile();
           
          // file = new File("config/serverconfig.xml");
        
            // Obtain factory instance
           
            
            // Parse document
           
        }
            catch(ParserConfigurationException | SAXException | IOException e){
               // createTheFile();
            e.printStackTrace();
            }
    }
    public String getServerName() {
        return serverName;
    }

    public void setServerName(String serverName) {
        this.serverName = serverName;
    }

    public String getPort() {
        return port;
    }

    public void setPort(String port) {
        this.port = port;
    }

    public String getDatabaseName() {
        return databaseName;
    }

    public void setDatabaseName(String databaseName) {
        this.databaseName = databaseName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String isRememberMe() {
        return rememberMe;
    }

    public void setRememberMe(String rememberMe) {
        this.rememberMe = rememberMe;
    }

    public String getReUsername() {
        return reUsername;
    }

    public void setReUsername(String reUsername) {
        this.reUsername = reUsername;
    }

    public String getRePassword() {
        return rePassword;
    }

    public void setRePassword(String rePassword) {
        this.rePassword = rePassword;
    }
    
    
    
    

public void save(){
try{
  
            
         //   Node root = doc.getElementsByTagName("serverconfig").item(0);
            
            Node servername = doc.getElementsByTagName("server-name").item(0);
            servername.setTextContent(getServerName());
            
            Node dataname = doc.getElementsByTagName("database-name").item(0);
            dataname.setTextContent(getDatabaseName());
            
            Node un = doc.getElementsByTagName("username").item(0);
            un.setTextContent(getUserName());
            
            Node pwd = doc.getElementsByTagName("password").item(0);
            pwd.setTextContent(getPassword());
            
           
           if(checkFields()){
           writeXml(doc,file);
           JOptionPane.showMessageDialog(null, "Proccess completed successfully");
          
           }
}catch(Exception ex){
JOptionPane.showMessageDialog(null, "Error "+ex);
}
}

//reading remeber me 
public void saveRememberMe(){
try{
  
            
         //   Node root = doc.getElementsByTagName("serverconfig").item(0);
            
            Node node1 = doc.getElementsByTagName("is-remembered").item(0);
            node1.setTextContent(isRememberMe());
            
            Node node2 = doc.getElementsByTagName("rem-username").item(0);
            node2.setTextContent(getReUsername());
            
            Node node3 = doc.getElementsByTagName("rem-password").item(0);
            node3.setTextContent(getRePassword());
           if(true){
           writeXml(doc,file);
           System.out.println("Proccess completed successfully");
          
           }
}catch(Exception ex){
JOptionPane.showMessageDialog(null, "Error "+ex);
}
}

public void readRememberMe(){
try{
  
            
         //   Node root = doc.getElementsByTagName("serverconfig").item(0);
            
            Node node1 = doc.getElementsByTagName("is-remembered").item(0);
            setRememberMe(node1.getTextContent());
            
            Node node2 = doc.getElementsByTagName("rem-username").item(0);
            setReUsername(node2.getTextContent());
            
            
            Node node3 = doc.getElementsByTagName("rem-password").item(0);
            setRePassword(node3.getTextContent());
          
}catch(Exception ex){
JOptionPane.showMessageDialog(null, "Error "+ex);
}
}

public void read(){
try{
            Node servername = doc.getElementsByTagName("server-name").item(0);
          setServerName(servername.getTextContent());
            
            Node dataname = doc.getElementsByTagName("database-name").item(0);
            setDatabaseName(dataname.getTextContent());
            
            Node un = doc.getElementsByTagName("username").item(0);
            setUserName(un.getTextContent());
            
            Node pwd = doc.getElementsByTagName("password").item(0);
            setPassword(pwd.getTextContent());

}catch(Exception ex){}

}



public  void writeXml(Document doc, File f) {
        try {
            // Create a DOM document for writing
            Source source = new DOMSource(doc);
            // Prepare the output file
            Result result = new StreamResult(f);
            // Create an instance of Transformer
            Transformer xformer = TransformerFactory.newInstance().newTransformer();
            // Write the DOM document to the file
            xformer.transform(source, result);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    boolean checkFields(){
    if(serverName.length() ==0 && databaseName.length() ==0){
   
    return false;
    }
    else{
    return true;
    }
    }
    
 /*  public static void main(String args[]){
    
    XMLConfiguration con = new XMLConfiguration();
    con.read();
    System.out.println(con.getServerName());
 // createTheFile();
    }*/
    
    
    public static boolean createTheFile(){
        File f1 = new File("config/");
        f1.mkdir();
    File f= new File("config/serverconfig.xml");
    try{
        try (FileWriter fw = new FileWriter(f)) {
            String xmlStructure = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\"?><!--\n" +
        "To change this template, choose Tools | Templates\n" +
        "and open the template in the editor.\n" +
        "--><config>\n" +
        "<server-config>\n" +
        "    <server-name>127.0.0.1</server-name>\n" +
        "    <port>\n" +
        "        3306\n" +
        "    </port>\n" +
        "    <database-name>identitycardgenerator</database-name>\n" +
        "    <username>root</username>\n" +
        "    <password></password>\n" +
        "</server-config>\n" +
        "<remember-me>\n" +
        "    <is-remembered>false</is-remembered>\n" +
        "    <rem-username></rem-username>\n" +
        "    <rem-password></rem-password>\n" +
        "</remember-me>\n" +
        "</config>";
            fw.write(xmlStructure);
            fw.close();
            System.out.println("File created");
        }
    }catch(IOException  e){}
    return true;
    }
}
